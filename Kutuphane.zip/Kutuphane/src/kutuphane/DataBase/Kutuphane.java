/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

package kutuphane.DataBase;
import java.sql.Connection;
import java.sql.SQLException;
/**
 *
 * @author Sami
 */
public class Kutuphane {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
        login giris = new login();
        giris.setVisible(true);
    }
    
}
